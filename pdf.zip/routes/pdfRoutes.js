// Arquivo: routes/pdfRoutes.js
// Data da Geração: 28 de agosto de 2025

const express = require('express');
const router = express.Router();
const multer = require('multer');
const { PDFDocument } = require('pdf-lib');
const mammoth = require('mammoth');
const puppeteer = require('puppeteer');
const pdfParse = require('pdf-parse');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// --- Configuração ---
const uploadDir = path.join(__dirname, '..', 'uploads');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const sessionPath = path.join(uploadDir, req.params.sessionId);
        fs.mkdirSync(sessionPath, { recursive: true });
        cb(null, sessionPath);
    },
    filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage: storage });
const jobs = new Map();

// --- Rotas de Sessão e Jobs ---
router.get('/', (req, res) => res.render('index', { title: 'Ferramenta PDF & DOCX Completa' }));

router.post('/session/create', (req, res) => {
    const sessionId = uuidv4();
    const sessionPath = path.join(uploadDir, sessionId);
    fs.mkdirSync(sessionPath, { recursive: true });
    jobs.set(sessionId, { status: 'created' });
    res.status(201).json({ sessionId });
});

router.post('/session/upload/:sessionId', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
    res.status(200).json({ fileId: req.file.filename });
});

router.post('/session/execute/:sessionId', (req, res) => {
    const { tool, files } = req.body;
    if (!jobs.has(req.params.sessionId)) return res.status(404).json({ error: 'Sessão não encontrada.' });
    
    processJob(req.params.sessionId, tool, files);
    res.status(202).json({ message: 'Processamento iniciado.' });
});

router.get('/session/status/:sessionId', (req, res) => {
    const job = jobs.get(req.params.sessionId);
    if (!job) return res.status(404).json({ error: 'Trabalho não encontrado.' });
    res.status(200).json(job);
});

router.get('/download/:sessionId/:fileName', (req, res) => {
    const { sessionId, fileName } = req.params;
    const filePath = path.join(uploadDir, sessionId, fileName);

    if (fs.existsSync(filePath)) {
        res.download(filePath, (err) => {
            if (!err) {
                fs.rm(path.join(uploadDir, sessionId), { recursive: true, force: true }, () => {});
                jobs.delete(sessionId);
            }
        });
    } else {
        res.status(404).send('Arquivo não encontrado ou a sessão expirou.');
    }
});

// --- Rota Síncrona (Rápida) ---
router.post('/pdf-para-docx', multer({ storage: multer.memoryStorage() }).single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
    try {
        const data = await pdfParse(req.file.buffer);
        const htmlContent = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body><p>${data.text.replace(/\n/g, '<br>')}</p></body></html>`;
        const docFileName = req.file.originalname.replace(/\.pdf$/, '.doc');
        res.setHeader('Content-Type', 'application/msword');
        res.setHeader('Content-Disposition', `attachment; filename=${docFileName}`);
        res.send(htmlContent);
    } catch (error) {
        res.status(500).json({ error: 'Ocorreu um erro ao extrair texto do PDF.' });
    }
});


// --- Lógica de Processamento em Segundo Plano ---
async function processJob(sessionId, tool, files) {
    const job = jobs.get(sessionId);
    jobs.set(sessionId, { ...job, status: 'processing' });
    const sessionPath = path.join(uploadDir, sessionId);

    try {
        let outputFileName;
        const inputFile = files ? path.join(sessionPath, files[0]) : null;
        const outputFile = path.join(sessionPath, `output_${sessionId}.tmp`);

        switch (tool) {
            case 'unir-pdf':
                outputFileName = `unido_${sessionId}.pdf`;
                const mergedPdf = await PDFDocument.create();
                for (const fileName of files) {
                    const fileBuffer = fs.readFileSync(path.join(sessionPath, fileName));
                    const pdf = await PDFDocument.load(fileBuffer);
                    const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
                    copiedPages.forEach(page => mergedPdf.addPage(page));
                }
                const mergedPdfBytes = await mergedPdf.save();
                fs.writeFileSync(path.join(sessionPath, outputFileName), mergedPdfBytes);
                break;
            
            case 'comprimir-pdf':
                outputFileName = files[0].replace(/\.pdf$/, `_comprimido_${sessionId}.pdf`);
                // **ALTERAÇÃO APLICADA AQUI**
                // Mudado de /ebook para /screen para maior compatibilidade, ao custo de um pouco de qualidade.
                await runExec(`gs -dSAFER -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/screen -dNOPAUSE -dQUIET -dBATCH -sOutputFile=${outputFile} ${inputFile}`);
                fs.renameSync(outputFile, path.join(sessionPath, outputFileName));
                break;

            case 'docx-para-pdf':
                outputFileName = files[0].replace(/\.docx?$/, `_${sessionId}.pdf`);
                const { value: html } = await mammoth.convertToHtml({ path: inputFile });
                const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
                const page = await browser.newPage();
                await page.setContent(html, { waitUntil: 'networkidle0' });
                const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '2.5cm', right: '2.5cm', bottom: '2.5cm', left: '2.5cm' } });
                await browser.close();
                fs.writeFileSync(path.join(sessionPath, outputFileName), pdfBuffer);
                break;

            case 'pdf-para-pdfa':
                outputFileName = files[0].replace(/\.pdf$/, `_pdfa_${sessionId}.pdf`);
                const gsDefPath = '/usr/share/ghostscript/9.55.0/lib/PDFA_def.ps';
                await runExec(`gs -dPDFA=2 -dBATCH -dNOPAUSE -sDEVICE=pdfwrite -sColorConversionStrategy=UseDeviceIndependentColor -sOutputFile=${outputFile} ${gsDefPath} ${inputFile}`);
                fs.renameSync(outputFile, path.join(sessionPath, outputFileName));
                break;
            
            default:
                throw new Error(`Ferramenta '${tool}' desconhecida.`);
        }
        
        jobs.set(sessionId, { status: 'complete', downloadUrl: `/download/${sessionId}/${outputFileName}` });

    } catch (error) {
        console.error(`Erro no trabalho ${sessionId} (${tool}):`, error);
        // **ALTERAÇÃO APLICADA AQUI**
        // Mensagem de erro mais clara para o usuário final.
        jobs.set(sessionId, { status: 'error', message: `Falha em '${tool}'. O arquivo pode estar corrompido, protegido ou em um formato incompatível.` });
    }
}

// Helper para prometer a execução de comandos
function runExec(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`Exec Error for command "${command}":`, stderr);
                return reject(error);
            }
            resolve(stdout);
        });
    });
}

module.exports = router;