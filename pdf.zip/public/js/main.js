document.addEventListener('DOMContentLoaded', () => {
    // --- LÓGICA DE UNIR PDF (COM PRÉ-VISUALIZAÇÃO E SESSÃO) ---
    const unirPdfCard = document.getElementById('unir-pdf-card');
    if (unirPdfCard) {
        const input = document.getElementById('unir-pdf-input');
        const button = document.getElementById('unir-pdf-button');
        const previewArea = document.getElementById('pdf-preview-area');
        const statusEl = document.getElementById('unir-pdf-status');
        const addButtonLabel = document.querySelector('label[for="unir-pdf-input"]');
        let sessionData = null;

        if (window.pdfjsLib) {
            pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js`;
        }
        new Sortable(previewArea, { animation: 150, ghostClass: 'sortable-ghost' });

        input.addEventListener('change', async (event) => {
            if (!sessionData) {
                sessionData = await startNewSession(statusEl);
                if (!sessionData) return;
            }
            
            const files = Array.from(event.target.files);
            input.disabled = true;
            addButtonLabel.classList.add('cursor-not-allowed', 'opacity-50');

            for (const file of files) {
                const card = generatePreviewCard(file);
                await uploadFile(sessionData.sessionId, file, card);
            }
            
            input.disabled = false;
            addButtonLabel.classList.remove('cursor-not-allowed', 'opacity-50');
            updateMergeButtonState();
            event.target.value = '';
        });

        const generatePreviewCard = (file) => {
            const card = document.createElement('div');
            card.className = 'relative group bg-gray-100 p-2 rounded-lg shadow-sm cursor-grab';
            card.innerHTML = `
                <div class="absolute inset-0 bg-blue-200 rounded-lg progress-bar" style="width: 0%; transition: width 0.3s;"></div>
                <div class="relative">
                    <canvas class="w-full h-auto rounded bg-white"></canvas>
                    <p class="text-xs text-center truncate mt-1">${file.name}</p>
                    <button class="delete-btn absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity hidden">&times;</button>
                </div>
            `;
            previewArea.appendChild(card);
            sessionData.files.set(card, { originalName: file.name, serverId: null, status: 'pending' });

            const fileReader = new FileReader();
            fileReader.onload = async (e) => {
                try {
                    const typedarray = new Uint8Array(e.target.result);
                    const pdf = await pdfjsLib.getDocument({ data: typedarray }).promise;
                    const page = await pdf.getPage(1);
                    const canvas = card.querySelector('canvas');
                    const context = canvas.getContext('2d');
                    const viewport = page.getViewport({ scale: 0.5 });
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    await page.render({ canvasContext: context, viewport: viewport }).promise;
                } catch (error) {
                    card.querySelector('.relative').innerHTML += `<div class="absolute inset-0 bg-red-100 flex items-center justify-center"><p class="text-xs text-red-700 text-center">Erro ao ler PDF</p></div>`;
                }
            };
            fileReader.readAsArrayBuffer(file);
            return card;
        };

        const uploadFile = async (sessionId, file, card) => {
            const formData = new FormData();
            formData.append('file', file);
            try {
                const response = await fetch(`/session/upload/${sessionId}`, { method: 'POST', body: formData });
                const data = await response.json();
                if (!response.ok) throw new Error(data.error);

                card.querySelector('.progress-bar').style.width = '100%';
                sessionData.files.get(card).serverId = data.fileId;
                sessionData.files.get(card).status = 'uploaded';
                card.querySelector('button').classList.remove('hidden');
            } catch (error) {
                card.querySelector('.relative').innerHTML += `<div class="absolute inset-0 bg-red-100 flex items-center justify-center"><p class="text-xs text-red-700 text-center">Falha no Upload</p></div>`;
                sessionData.files.get(card).status = 'error';
            }
        };

        const updateMergeButtonState = () => {
            if (!sessionData) return;
            const filesReady = Array.from(sessionData.files.values()).filter(f => f.status === 'uploaded').length;
            button.disabled = filesReady < 2;
        };

        button.addEventListener('click', async () => {
            const orderedCards = Array.from(previewArea.children);
            const orderedFileIds = orderedCards.map(card => sessionData.files.get(card)?.serverId).filter(id => id);
            
            showStatus(statusEl, 'Iniciando a união no servidor...', 'loading');
            button.disabled = true;
            addButtonLabel.classList.add('hidden');

            try {
                const response = await fetch(`/session/execute/${sessionData.sessionId}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tool: 'unir-pdf', files: orderedFileIds })
                });
                if (!response.ok) throw new Error((await response.json()).error);
                
                pollJobStatus(sessionData.sessionId, statusEl, button, addButtonLabel);
            } catch (error) {
                showStatus(statusEl, `Erro: ${error.message}`, 'error');
                button.disabled = false;
                addButtonLabel.classList.remove('hidden');
            }
        });
    }

    // --- LÓGICA GENÉRICA PARA FERRAMENTAS SIMPLES ---
    const setupSimpleTool = (toolId) => {
        const input = document.getElementById(`${toolId}-input`);
        const button = document.getElementById(`${toolId}-button`);
        const statusEl = document.getElementById(`${toolId}-status`);
        if (!button || !input) return;
        
        const isAsync = toolId !== 'pdf-para-docx';

        button.addEventListener('click', async () => {
            if (input.files.length === 0) { showStatus(statusEl, 'Selecione um arquivo.', 'error'); return; }
            const file = input.files[0];
            button.disabled = true;

            if (isAsync) {
                showStatus(statusEl, 'Iniciando sessão...', 'loading');
                const sessionData = await startNewSession(statusEl);
                if (!sessionData) { button.disabled = false; return; }

                showStatus(statusEl, 'Enviando arquivo...', 'loading');
                const uploadData = await uploadSingleFile(sessionData.sessionId, file);
                if (!uploadData) { showStatus(statusEl, 'Falha no upload.', 'error'); button.disabled = false; return; }

                showStatus(statusEl, 'Iniciando processamento...', 'loading');
                const executeResponse = await fetch(`/session/execute/${sessionData.sessionId}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tool: toolId, files: [uploadData.fileId] })
                });
                if (!executeResponse.ok) {
                    showStatus(statusEl, 'Falha ao iniciar o trabalho.', 'error');
                    button.disabled = false;
                } else {
                    pollJobStatus(sessionData.sessionId, statusEl, button);
                }
            } else { // Lógica Síncrona para PDF para DOCX
                const formData = new FormData();
                formData.append('file', file);
                showStatus(statusEl, 'Processando...', 'loading');
                try {
                    const response = await fetch('/pdf-para-docx', { method: 'POST', body: formData });
                    if (!response.ok) throw new Error((await response.json()).error);
                    const blob = await response.blob();
                    const disposition = response.headers.get('content-disposition');
                    const fileName = disposition ? disposition.split('filename=')[1].replace(/"/g, '') : `${toolId}-resultado`;
                    createDownloadLink(blob, fileName, blob.type, statusEl);
                } catch (e) {
                    showStatus(statusEl, `Falha: ${e.message}`, 'error');
                } finally {
                    button.disabled = false;
                }
            }
        });
    };

    // --- FUNÇÕES DE APOIO AO SISTEMA DE SESSÃO ---
    const startNewSession = async (statusEl) => {
        try {
            const response = await fetch('/session/create', { method: 'POST' });
            if (!response.ok) throw new Error('Falha ao criar sessão no servidor.');
            const data = await response.json();
            return { sessionId: data.sessionId, files: new Map() };
        } catch (error) {
            showStatus(statusEl, error.message, 'error');
            return null;
        }
    };
    
    const uploadSingleFile = async (sessionId, file) => {
        const formData = new FormData();
        formData.append('file', file);
        try {
            const response = await fetch(`/session/upload/${sessionId}`, { method: 'POST', body: formData });
            if (!response.ok) throw new Error('Falha no upload do arquivo.');
            return await response.json();
        } catch (e) {
            return null;
        }
    };

    const pollJobStatus = (sessionId, statusEl, button, addButtonLabel = null) => {
        const interval = setInterval(async () => {
            try {
                const response = await fetch(`/session/status/${sessionId}`);
                if (!response.ok) return;
                const data = await response.json();
                
                if (data.status === 'processing') {
                    showStatus(statusEl, 'Servidor está processando...', 'loading');
                } else if (data.status === 'complete') {
                    clearInterval(interval);
                    createDownloadLinkFromUrl(data.downloadUrl, data.downloadUrl.split('/').pop(), statusEl);
                    if (button) button.disabled = false;
                    if (addButtonLabel) addButtonLabel.classList.remove('hidden');
                } else if (data.status === 'error') {
                    clearInterval(interval);
                    showStatus(statusEl, `Erro: ${data.message}`, 'error');
                    if (button) button.disabled = false;
                    if (addButtonLabel) addButtonLabel.classList.remove('hidden');
                }
            } catch (e) {
                clearInterval(interval);
                showStatus(statusEl, 'Erro ao verificar status.', 'error');
                if (button) button.disabled = false;
                if (addButtonLabel) addButtonLabel.classList.remove('hidden');
            }
        }, 3000); // Verifica a cada 3 segundos
    };
    
    // Configuração das ferramentas
    setupSimpleTool('comprimir-pdf');
    setupSimpleTool('docx-para-pdf');
    setupSimpleTool('pdf-para-pdfa');
    setupSimpleTool('pdf-para-docx'); // Usa a lógica síncrona

    // --- FUNÇÕES DE AJUDA PARA UI ---
    function showStatus(element, message, type) { /* ...código completo da versão anterior... */ }
    function createDownloadLink(blob, fileName, mimeType, element) { /* ...código completo da versão anterior... */ }
    function createDownloadLinkFromUrl(url, fileName, element) {
        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        link.className = 'mt-4 inline-block bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2 px-4 rounded-full transition-all duration-300';
        link.textContent = `Baixar ${fileName}`;
        element.innerHTML = '';
        element.appendChild(link);
    }
});